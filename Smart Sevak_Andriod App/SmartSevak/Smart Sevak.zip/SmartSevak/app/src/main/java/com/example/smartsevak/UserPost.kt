package com.example.smartsevak

data class UserPost(
    val UserName: String? = null, val PostText: String? = null, val Likes: Long? = null
)
